<?php
/**
 * Plugin Name: IDONEO CMS Sync para Humano
 * Description: Notifica a Humano cuando se guardan o eliminan entradas/páginas para mantener el contenido sincronizado (bidireccional).
 * Version: 0.1.0
 * Author: IDONEO
 */

if (! defined('ABSPATH')) {
    exit;
}

class Humano_CMS_Sync {
    const OPT_URL    = 'humano_cms_sync_base_url';
    const OPT_TEAM   = 'humano_cms_sync_team_id';
    const OPT_SECRET = 'humano_cms_sync_secret';

    public function __construct() {
        add_action('admin_menu', [$this, 'register_settings_page']);
        add_action('admin_init', [$this, 'register_settings']);

        add_action('save_post', [$this, 'on_save_post'], 20, 3);
        add_action('trashed_post', [$this, 'on_trashed_post']);

        // Media library (attachments)
        add_action('add_attachment', [$this, 'on_add_attachment']);
        add_action('edit_attachment', [$this, 'on_edit_attachment']);
        add_action('delete_attachment', [$this, 'on_delete_attachment']);
    }

    public function register_settings_page() {
        add_options_page('IDONEO CMS Sync para Humano', 'IDONEO CMS Sync para Humano', 'manage_options', 'humano-cms-sync', [$this, 'render_settings_page']);
    }

    public function register_settings() {
        register_setting('humano_cms_sync', self::OPT_URL);
        register_setting('humano_cms_sync', self::OPT_TEAM);
        register_setting('humano_cms_sync', self::OPT_SECRET);
    }

    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1>IDONEO CMS Sync para Humano</h1>
            <form method="post" action="options.php">
                <?php settings_fields('humano_cms_sync'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="<?php echo esc_attr(self::OPT_URL); ?>">Humano base URL</label></th>
                        <td><input type="url" class="regular-text" id="<?php echo esc_attr(self::OPT_URL); ?>" name="<?php echo esc_attr(self::OPT_URL); ?>" value="<?php echo esc_attr(get_option(self::OPT_URL)); ?>" placeholder="https://humano.test" /></td>
                    </tr>
                    <tr>
                        <th><label for="<?php echo esc_attr(self::OPT_TEAM); ?>">Team ID</label></th>
                        <td><input type="number" id="<?php echo esc_attr(self::OPT_TEAM); ?>" name="<?php echo esc_attr(self::OPT_TEAM); ?>" value="<?php echo esc_attr(get_option(self::OPT_TEAM)); ?>" /></td>
                    </tr>
                    <tr>
                        <th><label for="<?php echo esc_attr(self::OPT_SECRET); ?>">Webhook secret</label></th>
                        <td><input type="text" class="regular-text" id="<?php echo esc_attr(self::OPT_SECRET); ?>" name="<?php echo esc_attr(self::OPT_SECRET); ?>" value="<?php echo esc_attr(get_option(self::OPT_SECRET)); ?>" /></td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
            <p>Endpoint: <code><?php echo esc_html(rtrim((string) get_option(self::OPT_URL), '/')); ?>/api/wordpress/webhook/<?php echo esc_html((string) get_option(self::OPT_TEAM)); ?></code></p>
        </div>
        <?php
    }

    private function syncable_type($post) {
        return in_array($post->post_type, ['post', 'page'], true);
    }

    public function on_save_post($post_id, $post, $update) {
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
            return;
        }
        if (! $this->syncable_type($post)) {
            return;
        }
        if (in_array($post->post_status, ['auto-draft', 'inherit'], true)) {
            return;
        }

        $this->notify($post_id, $post->post_type, $update ? 'updated' : 'created');
    }

    public function on_trashed_post($post_id) {
        $post = get_post($post_id);
        if (! $post || ! $this->syncable_type($post)) {
            return;
        }

        $this->notify($post_id, $post->post_type, 'trashed');
    }

    public function on_add_attachment($post_id) {
        $this->notify($post_id, 'attachment', 'created');
    }

    public function on_edit_attachment($post_id) {
        $this->notify($post_id, 'attachment', 'updated');
    }

    public function on_delete_attachment($post_id) {
        $this->notify($post_id, 'attachment', 'deleted');
    }

    private function notify($post_id, $type, $action) {
        $base   = rtrim((string) get_option(self::OPT_URL), '/');
        $team   = (string) get_option(self::OPT_TEAM);
        $secret = (string) get_option(self::OPT_SECRET);

        if ($base === '' || $team === '' || $secret === '') {
            return;
        }

        $endpoint = $base . '/api/wordpress/webhook/' . rawurlencode($team);

        wp_remote_post($endpoint, [
            'timeout'  => 5,
            'blocking' => false,
            'headers'  => [
                'Content-Type'    => 'application/json',
                'Accept'          => 'application/json',
                'X-Humano-Secret' => $secret,
            ],
            'body' => wp_json_encode([
                'id'     => (int) $post_id,
                'type'   => $type,
                'action' => $action,
            ]),
        ]);
    }
}

new Humano_CMS_Sync();
