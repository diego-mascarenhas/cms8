(function () {
    'use strict';

    if (typeof window.humanoChat === 'undefined') {
        return;
    }

    const config = window.humanoChat;
    const i18n = config.i18n || {};

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    function markdownToHtml(text) {
        if (!text) return '';
        let escaped = escapeHtml(text);
        escaped = escaped.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
        escaped = escaped.replace(/\*(.+?)\*/g, '<em>$1</em>');
        escaped = escaped.replace(/\[([^\]]+)\]\(([^)]+)\)/g, function (_, linkText, url) {
            const safeUrl = url.replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            return '<a href="' + safeUrl + '" target="_blank" rel="noopener noreferrer">' + linkText + '</a>';
        });
        escaped = escaped.replace(/^### (.+)$/gm, '<h4>$1</h4>');
        escaped = escaped.replace(/^## (.+)$/gm, '<h3>$1</h3>');
        escaped = escaped.replace(/^# (.+)$/gm, '<h3>$1</h3>');
        escaped = escaped.replace(/\n/g, '<br>');
        escaped = escaped.replace(/(<\/h[34]>)(<br>){2,}/g, '$1<br>');
        return escaped;
    }

    /**
     * Like markdownToHtml but handles partial content during typing: unclosed ** or *
     * render as bold/italic so the asterisks are never shown.
     */
    function markdownToHtmlPartial(text) {
        if (!text) return '';
        let escaped = escapeHtml(text);
        escaped = escaped.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
        escaped = escaped.replace(/\*\*([^*]*)$/g, '<strong>$1</strong>');
        escaped = escaped.replace(/\*(.+?)\*/g, '<em>$1</em>');
        escaped = escaped.replace(/\*([^*]*)$/g, '<em>$1</em>');
        escaped = escaped.replace(/\[([^\]]+)\]\(([^)]+)\)/g, function (_, linkText, url) {
            const safeUrl = url.replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            return '<a href="' + safeUrl + '" target="_blank" rel="noopener noreferrer">' + linkText + '</a>';
        });
        escaped = escaped.replace(/\[([^\]]+)\]\(([^)]*)$/g, '$1');
        escaped = escaped.replace(/^### (.+)$/gm, '<h4>$1</h4>');
        escaped = escaped.replace(/^## (.+)$/gm, '<h3>$1</h3>');
        escaped = escaped.replace(/^# (.+)$/gm, '<h3>$1</h3>');
        escaped = escaped.replace(/\n/g, '<br>');
        escaped = escaped.replace(/(<\/h[34]>)(<br>){2,}/g, '$1<br>');
        return escaped;
    }

    const TYPING_CHUNK = 2;
    const TYPING_DELAY_MS = 45;
    const TYPING_PAUSE_PARAGRAPH_TICKS = Math.max(1, Math.round(700 / TYPING_DELAY_MS));
    const TYPING_PAUSE_LINE_TICKS = Math.max(1, Math.round(280 / TYPING_DELAY_MS));

    function appendMessage(container, role, text, meta) {
        const msg = document.createElement('div');
        msg.className = 'humano-chat-msg humano-chat-msg-' + role;
        if (role === 'bot') {
            msg.innerHTML = markdownToHtml(text);
        } else {
            msg.innerHTML = escapeHtml(text);
        }
        if (meta) {
            const metaEl = document.createElement('div');
            metaEl.className = 'humano-chat-msg-meta';
            metaEl.textContent = meta;
            msg.appendChild(metaEl);
        }
        container.appendChild(msg);
        container.scrollTop = container.scrollHeight;
    }

    function appendBotMessageTyped(container, text, meta) {
        text = text != null ? String(text) : '';
        const msg = document.createElement('div');
        msg.className = 'humano-chat-msg humano-chat-msg-bot';
        container.appendChild(msg);
        let index = 0;
        let pauseTicks = 0;
        const timer = setInterval(function () {
            try {
                if (pauseTicks > 0) {
                    pauseTicks--;
                    container.scrollTop = container.scrollHeight;
                    return;
                }
                index += TYPING_CHUNK;
                if (index < text.length && index > 0) {
                    const code = text.charCodeAt(index - 1);
                    if (code >= 0xD800 && code <= 0xDBFF) {
                        index++;
                    }
                }
                index = Math.min(index, text.length);
                const partial = index >= text.length ? text : text.slice(0, index);
                msg.innerHTML = markdownToHtmlPartial(partial);
                container.scrollTop = container.scrollHeight;
                if (partial.endsWith('\n\n')) {
                    pauseTicks = TYPING_PAUSE_PARAGRAPH_TICKS;
                } else if (partial.endsWith('\n')) {
                    pauseTicks = TYPING_PAUSE_LINE_TICKS;
                }
                if (index >= text.length) {
                    clearInterval(timer);
                    if (meta) {
                        const metaEl = document.createElement('div');
                        metaEl.className = 'humano-chat-msg-meta';
                        metaEl.textContent = meta;
                        msg.appendChild(metaEl);
                    }
                    container.scrollTop = container.scrollHeight;
                }
            } catch (err) {
                clearInterval(timer);
                msg.innerHTML = markdownToHtml(text);
                if (meta) {
                    const metaEl = document.createElement('div');
                    metaEl.className = 'humano-chat-msg-meta';
                    metaEl.textContent = meta;
                    msg.appendChild(metaEl);
                }
                container.scrollTop = container.scrollHeight;
            }
        }, TYPING_DELAY_MS);
    }

    function showTypingIndicator(container) {
        const typing = document.createElement('div');
        typing.className = 'humano-chat-msg humano-chat-msg-bot humano-chat-typing';
        typing.setAttribute('aria-live', 'polite');
        typing.innerHTML = '<span class="humano-chat-typing-dot"></span><span class="humano-chat-typing-dot"></span><span class="humano-chat-typing-dot"></span>';
        container.appendChild(typing);
        container.scrollTop = container.scrollHeight;
        return typing;
    }

    function hideTypingIndicator(typingEl) {
        if (typingEl && typingEl.parentNode) {
            typingEl.parentNode.removeChild(typingEl);
        }
    }

    function setStatus(wrap, text, thinking) {
        const status = wrap.querySelector('.humano-chat-status');
        if (!status) return;
        if (wrap._humanoThinkingInterval) {
            clearInterval(wrap._humanoThinkingInterval);
            wrap._humanoThinkingInterval = null;
        }
        status.textContent = thinking ? '' : (text || '');
        status.classList.toggle('humano-chat-status-thinking', false);
    }

    function sendMessage(wrap) {
        const input = wrap.querySelector('.humano-chat-input');
        const sendBtn = wrap.querySelector('.humano-chat-send');
        const messages = wrap.querySelector('.humano-chat-messages');
        const text = (input && input.value) ? input.value.trim() : '';
        if (!text || !messages) return;

        input.value = '';
        input.style.height = 'auto';
        appendMessage(messages, 'user', text);

        sendBtn.disabled = true;
        const typingEl = showTypingIndicator(messages);

        const formData = new FormData();
        formData.append('action', config.action);
        formData.append('nonce', config.nonce);
        formData.append('message', text);
        if (config.promptKey) {
            formData.append('prompt_key', config.promptKey);
        }

        fetch(config.ajaxUrl, {
            method: 'POST',
            body: formData,
            credentials: 'same-origin',
        })
            .then(function (res) {
                return res.json();
            })
            .then(function (data) {
                hideTypingIndicator(typingEl);
                setStatus(wrap, '', false);
                sendBtn.disabled = false;
                if (data.success && data.data && data.data.response !== undefined) {
                    const responseText = data.data.response != null ? String(data.data.response) : '';
                    const routedTo = data.data.routed_to ? '→ ' + data.data.routed_to : null;
                    if (config.typingEffect) {
                        appendBotMessageTyped(messages, responseText, routedTo);
                    } else {
                        appendMessage(messages, 'bot', responseText, routedTo);
                    }
                } else {
                    appendMessage(
                        messages,
                        'error',
                        (data.data && data.data.message) || i18n.error || 'Something went wrong.'
                    );
                }
            })
            .catch(function () {
                hideTypingIndicator(typingEl);
                setStatus(wrap, '', false);
                sendBtn.disabled = false;
                appendMessage(messages, 'error', i18n.error || 'Something went wrong.');
            });
    }

    function bindWrap(wrap) {
        if (!wrap || wrap.dataset.humanoChatBound === 'true') return;
        wrap.dataset.humanoChatBound = 'true';

        const input = wrap.querySelector('.humano-chat-input');
        const sendBtn = wrap.querySelector('.humano-chat-send');

        function submit() {
            sendMessage(wrap);
        }

        if (sendBtn) {
            sendBtn.addEventListener('click', submit);
        }
        if (input) {
            input.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    submit();
                }
            });
            input.addEventListener('input', function () {
                this.style.height = 'auto';
                this.style.height = Math.min(this.scrollHeight, 120) + 'px';
            });
        }
    }

    function initInline() {
        document.querySelectorAll('.humano-chat-wrap').forEach(bindWrap);
    }

    function initFloating() {
        const floating = document.getElementById('humano-chat-floating');
        if (!floating || !config.floating) return;

        const btn = floating.querySelector('.humano-chat-float-btn');
        const panel = floating.querySelector('.humano-chat-float-panel');
        if (!btn || !panel) return;

        btn.addEventListener('click', function () {
            const open = panel.hidden;
            panel.hidden = !open;
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
            btn.setAttribute('aria-label', open ? (i18n.close || 'Close chat') : (i18n.open || 'Open chat'));
            if (open) {
                const inner = panel.querySelector('.humano-chat-wrap');
                if (inner) bindWrap(inner);
            }
        });

        bindWrap(panel.querySelector('.humano-chat-wrap'));
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            initInline();
            initFloating();
        });
    } else {
        initInline();
        initFloating();
    }
})();
