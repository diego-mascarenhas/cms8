=== Idoneo Chat for Humano ===
Contributors: idoneo
Tags: chat, chatbot, humano, assistant, widget
Requires at least: 5.8
Tested up to: 6.9
Stable tag: 0.9.3
Requires PHP: 7.4
License: AGPLv3.0 or later
License URI: https://www.gnu.org/licenses/agpl-3.0.html

Humano assistant chat for WordPress: shortcode or floating button; server-side team token. Not affiliated with Humano.

== Description ==

Idoneo Chat for Humano adds a chat widget to your WordPress site that talks to your **Humano** assistant (full assistant with router and flows). No coding required: configure the Base URL and API token in Settings, then use the shortcode or enable the floating button.

**Features:**

* Shortcode `[idoneo_chat]` to embed the chat anywhere (alias: `[humano_chat]`)
* Optional floating chat button on all front-end pages
* Team API token authentication (token never sent to the browser)
* Optional SSL verification toggle for local development
* Translatable (includes Spanish; follows site language)

**Requirements:**

* A Humano instance with the Assistant Chat API (POST `/api/team/assistant/chat`)
* A team API token from Humano (Team Settings → API Tokens). See your Humano /help for details.

== Installation ==

1. Install the plugin and activate it.
2. Go to **Settings → Idoneo Chat for Humano**.
3. Set **Humano Base URL** (e.g. `https://mi.humano.app`, no trailing slash).
4. Set **API Token** (from Humano: Team Settings → API Tokens).
5. Optionally enable **Floating widget** or use the shortcode `[idoneo_chat]` in any page or post.

== Frequently Asked Questions ==

= Where do I get the API token? =

Log in to your Humano app, go to Team Settings → API Tokens, generate a token and paste it in Settings → Idoneo Chat for Humano. Full documentation is in Humano's Help section (/help and API Authentication).

= Can I use this with a local Humano (.test) site? =

Yes. In Settings → Idoneo Chat for Humano you can uncheck "Verify SSL certificate" for local development (e.g. .test or self-signed certs). Do not disable SSL verification in production.

== Screenshots ==

1. Idoneo Chat for Humano settings page (Base URL, API Token, floating widget, SSL option).
2. Chat widget (inline or floating) with message input and send button.

== Changelog ==

= 0.9.3 =
* Admin settings: enqueue help box styles with wp_register_style, wp_enqueue_style, and wp_add_inline_style (WordPress.org guidelines).
* readme.txt: shorten plugin header description to 150 characters or fewer.

= 0.9.2 =
* Renamed to Idoneo Chat for Humano (slug: idoneo-chat-for-humano) per WordPress.org guidelines.
* Shortcode [idoneo_chat] with alias [humano_chat] for backwards compatibility.
* Directory assets (icons, banner) excluded from zip; upload via SVN after approval.

= 0.9.1 =
* Beta release.
* Shortcode [idoneo_chat] (alias [humano_chat]) and optional floating widget.
* Settings: Base URL, API token, prompt key, SSL verification.
* Spanish (es_ES, es_AR, es_MX) and English.

== Upgrade Notice ==

= 0.9.3 =
Maintenance release for WordPress.org review (admin CSS enqueue, readme short description).

= 0.9.2 =
Renamed to Idoneo Chat for Humano. Shortcode [idoneo_chat]; [humano_chat] still works. Settings moved to Settings → Idoneo Chat for Humano.

= 0.9.1 =
Beta release. Configure Base URL and API token in Settings → Idoneo Chat for Humano.
